template <class T> int size(const T &t);
